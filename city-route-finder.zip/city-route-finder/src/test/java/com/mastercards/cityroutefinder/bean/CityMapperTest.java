
package com.mastercards.cityroutefinder.bean;

import static org.junit.Assert.*;

import org.junit.Test;

public class CityMapperTest {

	private CityMapper cityMapper  = new CityMapper();
	@Test
	public void test() {
		String sortCities = cityMapper.sortCityNames("Trenton, Albany");
		assertEquals(sortCities,"albany, trenton");
	}

}
