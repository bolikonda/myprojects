package com.mastercards.cityroutefinder;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.mastercards.cityroutefinder.bean.CityMapper;

@Component
public class CityMapLoader implements CommandLineRunner {

	@Autowired
	private ResourceLoader resourceLoader;
	
	@Autowired
	private CityMapper cityList;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.boot.CommandLineRunner#run(java.lang.String[])
	 */
	@Override
	public void run(String... args) throws Exception {
		
		ArrayList<String> cityNames = new ArrayList<String>();

		Resource resource = resourceLoader.getResource("classpath:city.txt");
		File file = resource.getFile();

		Scanner scanner = new Scanner(file);
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			cityNames.add(cityList.sortCityNames(line));
		}
		cityList.setCityList(cityNames);
		scanner.close();
	}

}
