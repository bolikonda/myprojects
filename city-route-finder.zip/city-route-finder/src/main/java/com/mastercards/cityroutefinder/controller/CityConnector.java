package com.mastercards.cityroutefinder.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mastercards.cityroutefinder.bean.CityMapper;

@RestController
public class CityConnector {

	private static final Logger log = LoggerFactory.getLogger(CityConnector.class);
	private static final String YES = "yes";
	private static final String NO = "no";

	@Autowired
	private CityMapper cityMapper;

	@GetMapping("/connected")
	public String isRouteConnected(@RequestParam(value = "origin", required = false) String origin,
			@RequestParam(value = "destination", required = false) String destination) {

		try {
			log.info("Origin :" + origin + "& Destination:" + destination);
			if (cityMapper.getCityList()
					.contains(cityMapper.sortCityNames(origin.trim() + "," + destination.trim()).toString())) {
				log.info("Origin :" + origin + "& Destination:" + destination + " connected");
				return YES;
			}
			log.info("Origin :" + origin + "& Destination:" + destination + " not connected");
			return NO;
		} catch (Exception e) {
			log.info("Got exception: " + e.toString());
			return NO;
		}
	}

}
