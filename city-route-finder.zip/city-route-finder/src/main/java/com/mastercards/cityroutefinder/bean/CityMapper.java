
package com.mastercards.cityroutefinder.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;

import org.springframework.stereotype.Component;

import ch.qos.logback.core.net.SyslogOutputStream;


@Component
public class CityMapper {

	private ArrayList<String> cityList;

	
	
	/**
	 * 
	 */
	public CityMapper() {
		
	}

	/**
	 * @return the cityList
	 */
	public ArrayList<String> getCityList() {
		return cityList;
	}

	/**
	 * 
	 * @param cityList
	 */
	public void setCityList(ArrayList<String> cityList) {
		this.cityList = cityList;
	}

	/**
	 * method to sort city names
	 * @param cityNames
	 * @return
	 */
	public String sortCityNames(String cityNames) {
		String[] parts = cityNames.toLowerCase().trim().split(",");
		List<String> cities = new ArrayList<>();
		
		for (String s : parts) {
			cities.add(s.trim());
		}
		Collections.sort(cities);
		return String.join(", ", cities);
	}

}
