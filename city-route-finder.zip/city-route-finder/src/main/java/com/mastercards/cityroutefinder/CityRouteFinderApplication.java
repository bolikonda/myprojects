package com.mastercards.cityroutefinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityRouteFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityRouteFinderApplication.class, args);
	}

}
